using System.Collections.Generic;
using UnityEngine;
using System.Reflection;
using System;
using System.Runtime.InteropServices;

namespace ShaderHelper
{
    public static class Functions
    {
        public static void SetBuffer<T>(this ComputeShader shader, string buffername, List<T> list, int kernal = 0)
        {
            ComputeBuffer buffer = new(list.Count, Marshal.SizeOf<T>());
            buffer.SetData(list.ToArray());
            shader.SetBuffer(kernal, buffername, buffer);
        }
        public static void SetBuffer<T>(this Material shader, string buffername, List<T> list)
        {
            ComputeBuffer buffer = new(list.Count, Marshal.SizeOf<T>());
            buffer.SetData(list.ToArray());
            shader.SetBuffer(buffername, buffer);
        }

        public static void SetVar<T>(this Material shader, string name, T var)
        {
            if (var is Vector2 i0) shader.SetVector(name, i0);
            else if (var is Vector3 i1) shader.SetVector(name, i1);
            else if (var is Vector4 i2) shader.SetVector(name, i2);
            else if (var is int i3) shader.SetInteger(name, i3);
            else if (var is float i4) shader.SetFloat(name, i4);
            else if (var is bool i5) shader.SetInt(name, i5 ? 1 : 0);
            else if (var is Texture2D i6) shader.SetTexture(name, i6);
            else if (var is Matrix4x4 i7) shader.SetMatrix(name, i7);
            else if (var is Color i8) shader.SetColor(name, i8);
            else if (var is Texture3D i9) shader.SetTexture(name, i9);
            else if (var is RenderTexture i10) shader.SetTexture(name, i10);
            else Debug.LogError($"Type {typeof(T)} with name {name} is not supported by SetVar. Try setting manually.");
        }

        public static void SetVar<T>(this ComputeShader shader, string name, T var, int kernal = 0)
        {
            if (var is Vector2 i0) shader.SetVector(name, i0);
            else if (var is Vector3 i1) shader.SetVector(name, i1);
            else if (var is Vector4 i2) shader.SetVector(name, i2);
            else if (var is int i3) shader.SetInt(name, i3);
            else if (var is float i4) shader.SetFloat(name, i4);
            else if (var is bool i5) shader.SetBool(name, i5);
            else if (var is Texture2D i6) shader.SetTexture(kernal, name, i6);
            else if (var is Matrix4x4 i7) shader.SetMatrix(name, i7);
            else if (var is Texture3D i8) shader.SetTexture(kernal, name, i8);
            else if(var is RenderTexture i9) shader.SetTexture(kernal, name, i9);
            else Debug.LogError($"Type {typeof(T)} with name {name} is not supported by SetVar. Try setting manually.");
        }

        public static void SetStruct<T>(this ComputeShader shader, T instruct, string prefix = "Set_", int kernal = 0) where T : struct
        {
            FieldInfo[] fields = typeof(T).GetFields(BindingFlags.Public | BindingFlags.Instance);

            for (int i = 0; i < fields.Length; i++)
            {
                object value = fields[i].GetValue(instruct);
                shader.SetVar(prefix + fields[i].Name, value, kernal);
            }
        }

        public static void SetStruct<T>(this Material shader, T instruct, string prefix = "Set_") where T : struct
        {
            FieldInfo[] fields = typeof(T).GetFields(BindingFlags.Public | BindingFlags.Instance);

            for (int i = 0; i < fields.Length; i++)
            {
                object value = fields[i].GetValue(instruct);
                shader.SetVar(prefix + fields[i].Name, value);
            }
        }

        public static Vector4 ToVector4(this Quaternion q)
        {
            return new Vector4(q.x, q.y, q.z, q.w);
        }
    }
}

