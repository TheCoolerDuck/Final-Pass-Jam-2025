using UnityEngine;
using ShaderHelper;

[ExecuteAlways]
[RequireComponent(typeof(Camera))]
public class WorldDither : MonoBehaviour
{
    [Header("Shader Settings")]
    [Tooltip("Shader used for world-space dithering.")]
    [SerializeField] private Shader _ditherShader;

    [Tooltip("Size of Voronoi noise cells.")]
    [SerializeField, Min(0f)] private float _pointSize = 15f;

    [Tooltip("Dither threshold (0 = no effect, 1 = full effect).")]
    [SerializeField, Range(0f, 1f)] private float _threshold = 0f;

    [Tooltip("Distance at which the sky is rendered.")]
    [SerializeField, Min(0.001f)] private float _skyDistance = 5f;

    [Tooltip("Distance for the first anti-aliasing step.")]
    [SerializeField, Min(0f)] private float _firstAaDistance = 15f;

    [Tooltip("Speed at which the cell offset animates.")]
    [SerializeField, Min(0f)] private float _cellMoveSpeed = 1f;

    // Animated offset value for dithering grid
    private float _cellOffset = 15f;

    // Cached references
    private Camera _camera;
    private Material _material;

    /// <summary>
    /// Initializes camera reference and creates the material.
    /// </summary>
    private void OnEnable()
    {
        _camera = GetComponent<Camera>();
        CreateMaterial();
    }

    /// <summary>
    /// Cleans up the generated material to avoid memory leaks.
    /// </summary>
    private void OnDisable()
    {
        if (_material != null)
        {
            DestroyImmediate(_material);
            _material = null;
        }
    }

    /// <summary>
    /// Ensures the material instance exists.
    /// </summary>
    private void CreateMaterial()
    {
        if (_ditherShader == null)
        {
            Debug.LogError($"[{nameof(WorldDither)}] No shader assigned.", this);
            return;
        }

        if (_material == null)
        {
            _material = new Material(_ditherShader)
            {
                hideFlags = HideFlags.HideAndDontSave
            };
        }
    }

    /// <summary>
    /// Called after the camera has finished rendering. Applies the dithering effect.
    /// </summary>
    /// <param name="source">The rendered image.</param>
    /// <param name="destination">The target render texture.</param>
    private void OnRenderImage(RenderTexture source, RenderTexture destination)
    {
        // Ensure material is ready
        if (_material == null)
        {
            CreateMaterial();
            if (_material == null)
            {
                Graphics.Blit(source, destination);
                return;
            }
        }

        // Animate the cell offset
        _cellOffset += Time.deltaTime * _cellMoveSpeed;

        // Update all shader properties
        SetShaderProperties();

        // Blit with our custom material
        Graphics.Blit(source, destination, _material);
    }

    /// <summary>
    /// Called in the Editor whenever a serialized field is changed.
    /// Updates material parameters live.
    /// </summary>
    private void OnValidate()
    {
        if (_material != null && _camera != null)
        {
            SetShaderProperties();
        }
    }

    /// <summary>
    /// Computes camera-based values and pushes all parameters into the shader.
    /// </summary>
    private void SetShaderProperties()
    {
        // Compute tangent of half the vertical FOV (in radians)
        float tanHalfFov = Mathf.Tan(_camera.fieldOfView * 0.5f * Mathf.Deg2Rad);

        _material.SetVar("_tanOfHalfOfFov", tanHalfFov);
        _material.SetVar("pointSize", _pointSize);
        _material.SetVar("threshold", _threshold);
        _material.SetVar("CellOffset", _cellOffset);
        _material.SetVar("SkyDistance", _skyDistance);
        _material.SetVar("FirstAADist", _firstAaDistance);
    }
}


// ChatGPT commented and cleaned code; all functionality was written by A Duck